#!/usr/bin/env bash
# toggle-portal.sh
# Keeps you logged in by pinging and re-logging in if net goes down

PORTAL_HOST="https://cyberoam.iiitnr.edu.in:8090"
COOKIE_JAR="${HOME}/.portal_cookies"
PRODUCTTYPE="0"

USER="${COLLEGE_USER:-}"
PASS="${COLLEGE_PASS:-}"

escaped_user=$(printf '%s' "$USER" | sed "s/'/''/g")
ts() { date +%s%3N; }

login() {
  echo "[$(date)] Attempting login..."
  resp=$(curl -s -c "$COOKIE_JAR" -b "$COOKIE_JAR" \
    -H "Content-Type: application/x-www-form-urlencoded" \
    --data-urlencode "mode=191" \
    --data-urlencode "username=$escaped_user" \
    --data-urlencode "password=$PASS" \
    --data-urlencode "a=$(ts)" \
    --data-urlencode "producttype=$PRODUCTTYPE" \
    "${PORTAL_HOST}/login.xml")
  echo "[$(date)] Login response (first 200 chars):"
  echo "$resp" | cut -c1-200
}

while true; do
  if ping -c1 -W1 8.8.8.8 >/dev/null 2>&1; then
    sleep 1
  else
    echo "[$(date)] Internet down, trying login..."
    login
    sleep 5
  fi
done

