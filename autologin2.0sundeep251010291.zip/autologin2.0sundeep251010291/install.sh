#!/usr/bin/env bash
# install.sh
# Installer for toggle-portal.sh
# Run from the folder that contains toggle-portal.sh

set -euo pipefail

HERE="$PWD"
SRC_SCRIPT="toggle-portal.sh"

if [ ! -f "$HERE/$SRC_SCRIPT" ]; then
  echo "ERROR: $SRC_SCRIPT not found in $HERE. Put this installer in the same folder as the script and re-run."
  exit 1
fi

# Choose install dir
DEFAULT_INSTALL_DIR="${HOME}/.local/bin"
read -rp "Install toggle script to directory [${DEFAULT_INSTALL_DIR}]: " INSTALL_DIR
INSTALL_DIR="${INSTALL_DIR:-$DEFAULT_INSTALL_DIR}"

mkdir -p "$INSTALL_DIR"
chmod 755 "$INSTALL_DIR"

# Credentials storage
CFG_DIR="${HOME}/.config/toggle-portal"
mkdir -p "$CFG_DIR"
CREDFILE="${CFG_DIR}/credentials"

echo
echo "Enter credentials to store (these will be saved to $CREDFILE with mode 600)."
read -rp "Portal username: " COLLEGE_USER
read -srp "Portal password: " COLLEGE_PASS
echo
# write creds as exported env vars so scripts can source them
cat > "$CREDFILE" <<EOF
# toggle-portal credentials (created $(date))
export COLLEGE_USER='${COLLEGE_USER//\'/\''}' 
export COLLEGE_PASS='${COLLEGE_PASS//\'/\''}'
EOF
chmod 600 "$CREDFILE"
echo "Credentials saved to $CREDFILE (mode 600)."

# Copy main script
INSTALLED_SCRIPT="$INSTALL_DIR/$SRC_SCRIPT"
cp -f "$HERE/$SRC_SCRIPT" "$INSTALLED_SCRIPT"
chmod 755 "$INSTALLED_SCRIPT"
echo "Copied $SRC_SCRIPT -> $INSTALLED_SCRIPT"

# Create launcher wrapper that sources credentials and runs the installed script
LAUNCHER="$INSTALL_DIR/toggle-portal-run.sh"
cat > "$LAUNCHER" <<EOF
#!/usr/bin/env bash
# launcher wrapper - sources credentials then execs installed script
set -euo pipefail
CFG_FILE="\$HOME/.config/toggle-portal/credentials"
if [ -f "\$CFG_FILE" ]; then
  # shellcheck disable=SC1090
  source "\$CFG_FILE"
fi
exec "$INSTALLED_SCRIPT" "\$@"
EOF
chmod 755 "$LAUNCHER"
echo "Created launcher wrapper: $LAUNCHER"

# Create tail helper
TAIL_HELPER="${HOME}/tail-toggle-portal-log.sh"
cat > "$TAIL_HELPER" <<'EOF'
#!/usr/bin/env bash
LOGFILE="${HOME}/toggle-portal.log"
if [ ! -f "$LOGFILE" ]; then
  echo "Log file not found: $LOGFILE"
  exit 1
fi
echo "Tailing $LOGFILE (Ctrl-C to stop)..."
tail -f "$LOGFILE"
EOF
chmod 755 "$TAIL_HELPER"
echo "Created log tail helper: $TAIL_HELPER"

# Add crontab @reboot entry to start the service via nohup
CRON_CMD="nohup $LAUNCHER > ${HOME}/toggle-portal.log 2>&1 &"
# Check if crontab already contains our launcher
existing_crontab="$(crontab -l 2>/dev/null || true)"
if printf '%s\n' "$existing_crontab" | grep -Fq "$LAUNCHER"; then
  echo "Crontab already contains an entry for the launcher — skipping adding @reboot."
else
  # append the @reboot job
  tmpfile="$(mktemp)"
  printf '%s\n' "$existing_crontab" > "$tmpfile"
  printf '@reboot %s\n' "$CRON_CMD" >> "$tmpfile"
  crontab "$tmpfile"
  rm -f "$tmpfile"
  echo "Added @reboot crontab entry to start launcher at boot."
fi

echo
echo "INSTALL COMPLETE."
echo "- Installed script: $INSTALLED_SCRIPT"
echo "- Launcher wrapper: $LAUNCHER"
echo "- Credentials stored: $CREDFILE (mode 600)"
echo "- Log file on run: ~/toggle-portal.log"
echo "- To run now in background: nohup $LAUNCHER > ~/toggle-portal.log 2>&1 &"
echo "- To follow logs: $TAIL_HELPER"
echo
echo "If you want this available to all users, re-run this as root and choose /usr/local/bin as install dir."

